import PrimaryContact from '../components/contact_tiles/PrimaryContact';

function Contact() {
  return (
    <>
      <PrimaryContact />
    </>
  );
}

export default Contact;
